package com.maro.overlay;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    private WebView panel;
    private WindowManager.LayoutParams panelParams;
    private boolean open = false;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("maro_overlay", "Maro Overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            Notification notification = new Notification.Builder(this, "maro_overlay")
                .setContentTitle("Maro Overlay يعمل")
                .setContentText("اضغط الفقاعة الحمراء لفتح القائمة")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build();
            startForeground(7, notification);
        }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE); createBubble();
    }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
    private void createBubble() {
        TextView b = new TextView(this); b.setText("M"); b.setTextColor(0xffffffff); b.setTextSize(22); b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(0xffd80b20); b.setElevation(12); bubble = b;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(dp(54), dp(54), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP|Gravity.START; p.x = dp(12); p.y = dp(180);
        b.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction()==MotionEvent.ACTION_DOWN) { sx=e.getRawX(); sy=e.getRawY(); ox=p.x; oy=p.y; moved=false; return true; }
                if (e.getAction()==MotionEvent.ACTION_MOVE) { int dx=(int)(e.getRawX()-sx), dy=(int)(e.getRawY()-sy); if(Math.abs(dx)+Math.abs(dy)>8)moved=true; p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(bubble,p); return true; }
                if (e.getAction()==MotionEvent.ACTION_UP) { if(!moved) togglePanel(); return true; } return true;
            }
        });
        wm.addView(bubble,p);
    }
    private void togglePanel() { if(open) closePanel(); else showPanel(); }
    private void showPanel() {
        if(panel!=null) return;
        panel = new WebView(this); panel.setBackgroundColor(0x00000000); panel.getSettings().setJavaScriptEnabled(true); panel.getSettings().setDomStorageEnabled(true);
        panel.setWebViewClient(new WebViewClient()); panel.setWebChromeClient(new WebChromeClient()); panel.addJavascriptInterface(new Bridge(),"MaroOverlay");
        panel.loadUrl("file:///android_asset/menu.html");
        panelParams = new WindowManager.LayoutParams(dp(320), dp(520), overlayType(), WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        panelParams.gravity=Gravity.TOP|Gravity.END; panelParams.x=dp(8); panelParams.y=dp(90);
        wm.addView(panel,panelParams); open=true;
    }
    private void closePanel() { if(panel!=null){ wm.removeView(panel); panel.destroy(); panel=null; } open=false; }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private class Bridge { @JavascriptInterface public void close(){ android.os.Handler h=new android.os.Handler(getMainLooper()); h.post(() -> closePanel()); } }
    @Override public int onStartCommand(Intent i,int f,int id){ return START_STICKY; }
    @Override public void onDestroy(){ closePanel(); if(bubble!=null){wm.removeView(bubble);bubble=null;} super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
}
