package com.maro.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setBackgroundColor(0xff100307);
        TextView title = new TextView(this);
        title.setText("Maro Overlay"); title.setTextColor(0xffffffff); title.setTextSize(26);
        title.setGravity(Gravity.CENTER); title.setPadding(0, 12, 0, 20);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("اسمح للتطبيق بالظهور فوق التطبيقات الأخرى، ثم اضغط تشغيل الفقاعة العائمة. الأدوات هنا محلية ولا تتحكم في لاعبين أو غرف اللعبة.");
        info.setTextColor(0xffffc7cc); info.setTextSize(16); info.setPadding(0, 10, 0, 24);
        root.addView(info);
        Button permission = new Button(this); permission.setText("السماح بالظهور فوق التطبيقات");
        root.addView(permission);
        Button start = new Button(this); start.setText("تشغيل القائمة العائمة"); root.addView(start);
        Button stop = new Button(this); stop.setText("إيقاف القائمة"); root.addView(stop);
        setContentView(root);
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) startService(new Intent(this, OverlayService.class));
            else permission.performClick();
        });
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
    }
}
